# LEYA SOLAR Customer Manager — Android Studio Project

This is the source project for an Android WebView app. It bundles the English customer manager in the app, uses WebView local storage for records, lets the user select a JSON backup for Restore Backup, and routes CSV/JSON exports into `Downloads/LEYA_SOLAR`.

## Build an APK

1. Install Android Studio on a computer and install Android SDK Platform 35 (Android 15) and a compatible JDK.
2. Open this folder (`LEYA_SOLAR_Android_Project`) in Android Studio.
3. Allow Gradle sync to complete.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. After the build completes, use the notification's **locate** link. The debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone, open it, and approve installing from that source if Android asks.

## Features

- English labels and fields: customer, phone, location, work type, commitment/completion dates, status, work charge, payment status, paid amount, notes/history.
- Search and status/payment filters.
- Edit/delete, call and WhatsApp shortcuts.
- Local browser storage inside the app.
- JSON backup/restore and CSV export.
- Backup/export files saved to `Downloads/LEYA_SOLAR`.

## Important storage notes

Records are stored locally in the app's WebView. They do not automatically sync to another phone. Use **Backup Data** regularly and keep the JSON file somewhere safe. Uninstalling the app or clearing app data can remove the records. Test backup and restore with sample records before using it for business-critical data.

## Build status

This source project is prepared, but an APK binary has not been compiled in this environment because Android SDK/Gradle tooling is not installed here.
